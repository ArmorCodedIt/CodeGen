if ran locally(originally on repl) extract the files from the zip (or git clone it) into a folder and cd into it

do python options2.py to have it print on shell
and to have it printed onto a file do python main.py

to use bester do cd script2
then python bestercredit.py

Thanks for using make sure to use the codeshere.txt file to keep your codes as each run will update the output.txt file!
Same goes with credit.txt in the file there is another txt (yourcreds.txt) put any generated cards there if you want to keep them!

Warning!:This is for Fun and i am not responsible for any working codes that get your account BANNED! Nor am i responsible for what you do with the things you generate This is just something i wanted to make to laugh about Thank you!


Donate if you like!


BTC:bc1q5atfh93dhlv8t6fd9676xd0dp6qup953nkpq0w

Doge:D9sz8uDrQPaGGRirjzszEqcZvo4hFqJRB

Thank you!