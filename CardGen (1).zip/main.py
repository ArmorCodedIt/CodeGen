import string
import random
import requests
import os,sys
import subprocess
import glob
from os import path


f = open('output.txt','w')
sys.stdout = f




letters = string.ascii_uppercase

print(''.join(random.choice(letters) for i in range(25)))

letters = string.ascii_uppercase

print(''.join(random.choice(letters) for i in range(16)))

letters = string.digits

print(''.join(random.choice(letters) for i in range(12)))


letters = string.ascii_uppercase

print(''.join(random.choice(letters) for i in range(25)))

letters = string.ascii_uppercase

print(''.join(random.choice(letters) for i in range(16)))

letters = string.digits

print(''.join(random.choice(letters) for i in range(12)))

letters = string.ascii_uppercase

print(''.join(random.choice(letters) for i in range(25)))

letters = string.ascii_uppercase

print(''.join(random.choice(letters) for i in range(16)))

letters = string.digits

print(''.join(random.choice(letters) for i in range(12)))

letters = string.ascii_uppercase

print(''.join(random.choice(letters) for i in range(25)))

letters = string.ascii_uppercase

print(''.join(random.choice(letters) for i in range(16)))

letters = string.digits

print(''.join(random.choice(letters) for i in range(12)))

letters = string.ascii_uppercase

print(''.join(random.choice(letters) for i in range(25)))

letters = string.ascii_uppercase

print(''.join(random.choice(letters) for i in range(16)))

letters = string.digits

print(''.join(random.choice(letters) for i in range(12)))

letters = string.ascii_uppercase

print(''.join(random.choice(letters) for i in range(25)))

letters = string.ascii_uppercase

print(''.join(random.choice(letters) for i in range(16)))

letters = string.digits

print(''.join(random.choice(letters) for i in range(12)))

print("Thanks for using make sure to use the codeshere.txt file to keep your codes as each run will update the output.txt file!")